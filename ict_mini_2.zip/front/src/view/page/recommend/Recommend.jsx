import '../../../css/page/recommend/recommend.css';
import Faded from '../../../effect/Faded';

function Recommend(){
    return(
        <Faded>
            <div className="recommend-container">
                Recommend
            </div>
        </Faded>
    )
}

export default Recommend;