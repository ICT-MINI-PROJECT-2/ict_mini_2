import '../css/footer.css';

function Footer() {
    return (
      <div className="footer">
        Footer
      </div>
    );
  }
  
  export default Footer;
  