import '../../css/user/checklist.css';
function CheckList(){

    const checkBoxList = ['한식','패스트푸드','일식','중국식','아시아음식','양식','주점','분식','뷔페','패밀리레스토랑','기타'];

    return(
        <div className="checklist-container">
            <div id ="checklist-title">선호음식</div>
            <form id = "checklistForm" name="ckecklistFrom">
                <div id="boxes">
                    <input type='checkbox' id='foodSelect' value={"korean"} name='korean' onChange={""}/><span>한식</span>
                    <input type='checkbox' id='foodSelect' value={"chinese"} name='chinese' onChange={""}/><span>중국식</span>
                    <input type='checkbox' id='foodSelect' value={"japanese"} name='japanese' onChange={""}/><span>일식</span>
                    <input type='checkbox' id='foodSelect' value={"western"} name='western' onChange={""}/><span>양식</span>
                    <input type='checkbox' id='foodSelect' value={"asian"} name='asian' onChange={""}/><span>아시아음식</span>
                    <input type='checkbox' id='foodSelect' value={"fastfood"} name='fastfood' onChange={""}/><span>패스트푸드</span>
                    <input type='checkbox' id='foodSelect' value={"alchol"} name='alchol' onChange={""}/><span>주점</span>
                    <input type='checkbox' id='foodSelect' value={"snack"} name='snack' onChange={""}/><span>분식</span>
                    <input type='checkbox' id='foodSelect' value={"buffet"} name='buffet' onChange={""}/><span>뷔페</span>
                    <input type='checkbox' id='foodSelect' value={"familyrestaurant"} name='familyrestaurant' onChange={""}/><span>페밀리레스토랑</span>
                    <input type='checkbox' id='foodSelect' value={"others"} name='ohters' onChange={""}/><span>기타</span>
                </div>
            </form> 
        </div>
    );
}
export default CheckList;