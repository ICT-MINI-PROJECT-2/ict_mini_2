import '../../css/user/mypage.css';
import Faded from '../../effect/Faded'
function MyPage(){
    return(
        <Faded>
            <div className="mypage-container">
                mypage
            </div>
        </Faded>
    )
}

export default MyPage;